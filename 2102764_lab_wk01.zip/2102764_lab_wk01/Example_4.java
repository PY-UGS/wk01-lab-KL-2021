public class Example_4 {
    public static void main(String[] args) {
    
        for(int x = 102; x >= 66; x--){
            if(x%2==1){
                System.out.println("value of x: " + x);
            }
        }
    }
}
